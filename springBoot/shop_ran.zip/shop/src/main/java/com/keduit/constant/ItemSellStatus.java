package com.keduit.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
