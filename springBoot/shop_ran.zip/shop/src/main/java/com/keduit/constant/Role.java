package com.keduit.constant;

public enum Role {
    USER, ADMIN
}
