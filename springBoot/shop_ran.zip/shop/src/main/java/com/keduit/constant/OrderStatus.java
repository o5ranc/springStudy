package com.keduit.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
