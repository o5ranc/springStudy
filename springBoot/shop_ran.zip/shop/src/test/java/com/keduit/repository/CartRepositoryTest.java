package com.keduit.repository;

public class CartRepositoryTest {
}
